package com.neo.plus.iosluancher

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The Neo Plus iOS-style lock screen: big clock, date, wallpaper, and "Swipe up to unlock".
 *
 * It is drawn ABOVE Android's own lock screen (showWhenLocked) and is only a front door: Android's lock is still underneath.
 * Swiping up (or tapping) asks Android to dismiss its own lock with [KeyguardManager.requestDismissKeyguard]. Android then shows
 * the phone's real unlock for whatever the phone uses (fingerprint, face, PIN, pattern, password, smart lock, or a plain swipe if
 * the phone has no lock). Neo Plus never sees or checks the PIN, pattern or fingerprint, so every lock type works and none can
 * be bypassed from here.
 *
 * Because it is visible before anyone has unlocked the phone, it shows ONLY the time, the date and HOW MANY notifications wait,
 * never their text, names or app icons.
 */
class NeoLockScreenActivity : ComponentActivity() {

    companion object {
        /** True while the phone's own lock is up and this screen is wanted. */
        fun shouldShow(ctx: Context): Boolean {
            if (!AppLock.lockScreenOn(ctx)) return false
            val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager ?: return false
            return km.isKeyguardLocked
        }

        fun start(ctx: Context) {
            val i = Intent(ctx.applicationContext, NeoLockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            try { ctx.applicationContext.startActivity(i) } catch (e: Exception) { }
        }
    }

    private var dismissing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)   // no screenshots of the lock screen
        setContent { LockScreen(onUnlock = { requestUnlock() }) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun onStop() {
        // Leaving (Home, another app, screen off) closes it, unless Android's own unlock is on screen right now
        if (!dismissing && !isChangingConfigurations) finish()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        // Already unlocked (for example by Smart Lock or face unlock while this was up): nothing to show
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) finish()
    }

    /** Asks Android to open ITS OWN unlock: it shows fingerprint, face, PIN, pattern or password as the phone is set up. */
    private fun requestUnlock() {
        if (dismissing) return
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) { finish(); return }
        dismissing = true
        try {
            km.requestDismissKeyguard(this as Activity, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    dismissing = false
                    // The phone's own unlock just passed, so the Neo Plus lock does not ask a second time right away
                    if (km.isDeviceSecure) AppLock.unlocked(applicationContext, "", true)
                    finish()
                }
                override fun onDismissCancelled() { dismissing = false }
                override fun onDismissError() { dismissing = false }
            })
        } catch (e: Exception) { dismissing = false }
    }
}

@Composable
private fun LockScreen(onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }

    val is24 = DateFormat.is24HourFormat(ctx)
    val time = SimpleDateFormat(if (is24) "H:mm" else "h:mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    val waiting = NeoNotificationService.items.size
    var drag by remember { mutableStateOf(0f) }
    var fired by remember { mutableStateOf(false) }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.45f))))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f; fired = false },
                    onDragEnd = { drag = 0f },
                    onDragCancel = { drag = 0f },
                    onVerticalDrag = { _, dy ->
                        drag += dy
                        if (!fired && drag < -140f) { fired = true; onUnlock() }   // swiped up
                    }
                )
            }
            .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onUnlock() }
    ) {
        Column(
            Modifier.fillMaxWidth().statusBarsPadding().padding(top = 72.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(date, color = Color.White.copy(alpha = 0.9f), fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(time, color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
            if (waiting > 0) {
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.20f))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        if (waiting == 1) "1 notification" else "$waiting notifications",
                        color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("⌃", color = Color.White.copy(alpha = 0.8f), fontSize = 22.sp)
            Text("Swipe up to unlock", color = Color.White.copy(alpha = 0.9f), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.size(width = 134.dp, height = 5.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.85f)))
        }
    }
}
