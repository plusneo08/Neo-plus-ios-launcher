package com.neo.plus.iosluancher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow

/**
 * Incoming-notification alert drawn over every app and the home screen:
 *  - the edges of the screen flash (three quick pulses) in the colour of the app that sent the notification
 *  - a banner slides in at the top-left corner with the app icon and, beside it, the app name, the title and the message
 * Tap the banner to open the notification, swipe it to the left to dismiss it. It hides by itself after a few seconds.
 * Needs "Display over other apps" (the same permission the message orbs use) and Notification access.
 */
object EdgeAlert {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("neo_edge_alert", Context.MODE_PRIVATE)
    fun enabled(ctx: Context): Boolean = prefs(ctx).getBoolean("on", true)
    fun setEnabled(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean("on", on).apply() }
    fun canShow(ctx: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

    private const val FLASH_MS = 1800L
    private const val STAY_MS = 4800L
    private val DEFAULT_ACCENT = Color.rgb(125, 211, 252)

    private val main = Handler(Looper.getMainLooper())
    private val seen = HashMap<String, Int>()
    private val icons = HashMap<String, Bitmap?>()

    private var wm: WindowManager? = null
    private var flash: FlashView? = null
    private var flashAnim: ValueAnimator? = null
    private var banner: LinearLayout? = null
    private var hide: Runnable? = null

    private val skipCategories = setOf(
        Notification.CATEGORY_TRANSPORT, Notification.CATEGORY_PROGRESS, Notification.CATEGORY_SERVICE,
        Notification.CATEGORY_SYSTEM, Notification.CATEGORY_STATUS, Notification.CATEGORY_CALL,
        Notification.CATEGORY_ALARM
    )

    /** Called for every posted notification; decides whether it is worth an alert. */
    fun onPosted(ctx: Context, sbn: StatusBarNotification) {
        val app = ctx.applicationContext
        if (!enabled(app) || !canShow(app)) return
        if (sbn.packageName == app.packageName) return
        val n = sbn.notification ?: return
        val skipFlags = Notification.FLAG_ONGOING_EVENT or Notification.FLAG_GROUP_SUMMARY or Notification.FLAG_FOREGROUND_SERVICE
        if ((n.flags and skipFlags) != 0) return
        if (n.category in skipCategories) return
        if (isQuiet(sbn)) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty().trim()
        if (title.isBlank() && text.isBlank()) return

        // The same notification updated with the same words is not new
        val hash = (title + "|" + text).hashCode()
        if (seen[sbn.key] == hash) return
        seen[sbn.key] = hash
        if (seen.size > 200) seen.clear()

        // Nothing to flash while the screen is off
        val pw = app.getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (pw != null && !pw.isInteractive) return

        val label = try {
            app.packageManager.getApplicationLabel(app.packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }
        show(app, label, title, text, iconFor(app, sbn.packageName), n.contentIntent)
    }

    /** Silent notifications (low importance: promotions, background chatter) do not get the flash. */
    private fun isQuiet(sbn: StatusBarNotification): Boolean {
        try {
            val l = NeoNotificationService.instance ?: return false
            val r = NotificationListenerService.Ranking()
            if (l.currentRanking.getRanking(sbn.key, r)) {
                val imp = r.importance
                return imp != NotificationManager.IMPORTANCE_UNSPECIFIED && imp < NotificationManager.IMPORTANCE_DEFAULT
            }
        } catch (e: Exception) { }
        return false
    }

    /** Shows a sample alert, so the person sees what it looks like when they switch it on. */
    fun demo(ctx: Context) {
        val app = ctx.applicationContext
        show(app, "NEO PLUS", "Edge alert is on",
            "New notifications flash the edges of the screen like this.", iconFor(app, app.packageName), null)
    }

    fun show(ctx: Context, app: String, title: String, text: String, icon: Bitmap?, intent: android.app.PendingIntent?) {
        val c = ctx.applicationContext
        main.post { try { showNow(c, app, title, text, icon, intent) } catch (e: Exception) { } }
    }

    private fun iconFor(c: Context, pkg: String): Bitmap? = icons.getOrPut(pkg) {
        try { renderIcon(c.packageManager.getApplicationIcon(pkg), 96) } catch (e: Exception) { null }
    }

    /** The app's main colour (ignoring white, grey and black), made bright so it glows on a dark screen. */
    private fun accentOf(b: Bitmap): Int {
        return try {
            val s = Bitmap.createScaledBitmap(b, 8, 8, true)
            var r = 0L; var g = 0L; var bl = 0L; var n = 0L
            val hsv = FloatArray(3)
            for (y in 0 until 8) for (x in 0 until 8) {
                val p = s.getPixel(x, y)
                if (Color.alpha(p) < 128) continue
                Color.colorToHSV(p, hsv)
                if (hsv[1] < 0.25f || hsv[2] < 0.25f) continue
                r += Color.red(p); g += Color.green(p); bl += Color.blue(p); n++
            }
            if (n == 0L) DEFAULT_ACCENT
            else {
                Color.colorToHSV(Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt()), hsv)
                hsv[1] = maxOf(hsv[1], 0.6f)
                hsv[2] = 1f
                Color.HSVToColor(hsv)
            }
        } catch (e: Exception) { DEFAULT_ACCENT }
    }

    private fun dp(c: Context, v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.resources.displayMetrics)

    /* ---------------------------------- showing ---------------------------------- */

    private fun showNow(c: Context, app: String, title: String, text: String, icon: Bitmap?, intent: android.app.PendingIntent?) {
        val w = wm ?: (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).also { wm = it }
        clear(w)
        val accent = if (icon != null) accentOf(icon) else DEFAULT_ACCENT
        addFlash(c, w, accent)
        addBanner(c, w, app, title, text, icon, intent, accent)
    }

    private fun clear(w: WindowManager) {
        hide?.let { main.removeCallbacks(it) }
        hide = null
        flashAnim?.let { it.removeAllListeners(); it.cancel() }
        flashAnim = null
        removeFlash(w)
        removeBanner(w)
    }

    private fun removeFlash(w: WindowManager) {
        flash?.let { try { w.removeView(it) } catch (e: Exception) { } }
        flash = null
    }

    private fun removeBanner(w: WindowManager) {
        banner?.let { try { w.removeView(it) } catch (e: Exception) { } }
        banner = null
    }

    private fun addFlash(c: Context, w: WindowManager, accent: Int) {
        val v = FlashView(c, accent)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        w.addView(v, lp)
        flash = v
        flashAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = FLASH_MS
            addUpdateListener { v.level = it.animatedValue as Float }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { if (flash === v) removeFlash(w) }
            })
            start()
        }
    }

    private fun addBanner(
        c: Context, w: WindowManager, app: String, title: String, text: String,
        icon: Bitmap?, intent: android.app.PendingIntent?, accent: Int
    ) {
        val screenW = c.resources.displayMetrics.widthPixels
        val cardW = minOf(dp(c, 340f).toInt(), screenW - dp(c, 16f).toInt())

        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(c, 10f).toInt(), dp(c, 10f).toInt(), dp(c, 14f).toInt(), dp(c, 10f).toInt())
        row.background = GradientDrawable().apply {
            cornerRadius = dp(c, 20f)
            setColor(Color.parseColor("#EB11151F"))
            setStroke(dp(c, 1.5f).toInt(), Color.argb(170, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        row.elevation = dp(c, 8f)

        val iv = ImageView(c)
        if (icon != null) iv.setImageBitmap(icon)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        val radius = dp(c, 10f)
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setRoundRect(0, 0, view.width, view.height, radius) }
        }
        iv.clipToOutline = true
        row.addView(iv, LinearLayout.LayoutParams(dp(c, 40f).toInt(), dp(c, 40f).toInt()))

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.addView(TextView(c).apply {
            this.text = app.uppercase()
            setTextColor(Color.argb(170, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (title.isNotBlank()) col.addView(TextView(c).apply {
            this.text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (text.isNotBlank()) col.addView(TextView(c).apply {
            this.text = text
            setTextColor(Color.argb(225, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(c, 12f).toInt()
        })

        val sbId = c.resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusH = if (sbId > 0) c.resources.getDimensionPixelSize(sbId) else dp(c, 24f).toInt()
        val lp = WindowManager.LayoutParams(
            cardW, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(c, 8f).toInt()
            y = statusH + dp(c, 2f).toInt()
        }

        val slop = ViewConfiguration.get(c).scaledTouchSlop
        var downX = 0f
        var dx = 0f
        var moved = false
        row.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX; dx = 0f; moved = false
                    cancelHide()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    dx = ev.rawX - downX
                    if (abs(dx) > slop) moved = true
                    if (moved) v.translationX = minOf(0f, dx)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        try { intent?.send() } catch (e: Exception) { }
                        dismiss(w, row)
                    } else if (dx < -dp(c, 70f)) {
                        dismiss(w, row)
                    } else {
                        v.animate().translationX(0f).setDuration(160).start()
                        scheduleHide(w, row)
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.animate().translationX(0f).setDuration(160).start()
                    scheduleHide(w, row)
                    true
                }
                else -> false
            }
        }

        w.addView(row, lp)
        banner = row
        row.translationX = -cardW.toFloat()
        row.alpha = 0f
        row.animate().translationX(0f).alpha(1f).setDuration(380).setInterpolator(OvershootInterpolator(0.9f)).start()
        scheduleHide(w, row)
    }

    private fun cancelHide() {
        hide?.let { main.removeCallbacks(it) }
        hide = null
    }

    private fun scheduleHide(w: WindowManager, row: View) {
        cancelHide()
        val r = Runnable { dismiss(w, row) }
        hide = r
        main.postDelayed(r, STAY_MS)
    }

    private fun dismiss(w: WindowManager, row: View) {
        if (banner !== row) return
        cancelHide()
        val away = -(row.width + dp(row.context, 16f))
        row.animate().translationX(away).alpha(0f).setDuration(260).setInterpolator(AccelerateInterpolator())
            .withEndAction { if (banner === row) removeBanner(w) }
            .start()
    }

    /* ---------------------------------- the flashing edges ---------------------------------- */

    private class FlashView(c: Context, private val color: Int) : View(c) {
        /** 0..1 progress of the whole effect. */
        var level = 0f
            set(v) { field = v; invalidate() }

        private val edge = 34f * c.resources.displayMetrics.density
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private var top: Shader? = null
        private var bottom: Shader? = null
        private var left: Shader? = null
        private var right: Shader? = null

        private fun grad(x0: Float, y0: Float, x1: Float, y1: Float): Shader {
            val clear = Color.argb(0, Color.red(color), Color.green(color), Color.blue(color))
            val mid = Color.argb(90, Color.red(color), Color.green(color), Color.blue(color))
            return LinearGradient(x0, y0, x1, y1, intArrayOf(color, mid, clear), floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        }

        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            val wf = w.toFloat(); val hf = h.toFloat()
            top = grad(0f, 0f, 0f, edge)
            bottom = grad(0f, hf, 0f, hf - edge)
            left = grad(0f, 0f, edge, 0f)
            right = grad(wf, 0f, wf - edge, 0f)
        }

        override fun onDraw(cv: Canvas) {
            val t = level
            // three quick pulses that fade away
            val k = (1f - t).pow(0.8f) * (0.45f + 0.55f * abs(cos(3.0 * PI * t)).toFloat())
            p.alpha = (255f * k).toInt().coerceIn(0, 255)
            val w = width.toFloat(); val h = height.toFloat()
            p.shader = top; cv.drawRect(0f, 0f, w, edge, p)
            p.shader = bottom; cv.drawRect(0f, h - edge, w, h, p)
            p.shader = left; cv.drawRect(0f, 0f, edge, h, p)
            p.shader = right; cv.drawRect(w - edge, 0f, w, h, p)
        }
    }
}
