package com.neo.plus.iosluancher

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

/* ------------------------------------------------------------------ */
/*  Results of a comparison, before they are written to a file          */
/* ------------------------------------------------------------------ */

/** One table of the result: what changed / was added / was removed. [kind] = changed | added | removed | plain. */
class DiffSection(val title: String, val headers: List<String>, val rows: List<List<String>>, val kind: String)

class DiffResult(
    val title: String,
    val subtitle: String,
    val stats: List<DocStat>,
    val summary: String,
    val summaryKind: String,
    val sections: List<DiffSection>,
    val notes: List<String>
)

/**
 * Assistant actions:
 *  - compare_files: compares two files and writes the result as a report in the SAME kind of file as the one it was given
 *    (.xlsx -> .xlsx, .csv -> .csv, .docx -> .docx, .txt -> .txt) unless another format is asked for.
 *  - word_report: writes a Word report with a styled layout from what the assistant tells it (and, if asked, the tasks Neo finished).
 * Both save the file in Downloads/NeoPlus and end the note with "(file: name)", which the chat turns into a card to open or share.
 */
object ReportActions {

    /* ---------------------------- reading files ---------------------------- */

    private fun decode(s: String): String =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    /** Every line of a text file or paragraph of a Word file, trimmed, blanks dropped. */
    private fun textLines(f: File): List<String> {
        val raw = if (f.extension.lowercase() == "docx") {
            ZipFile(f).use { z ->
                val xml = z.getInputStream(z.getEntry("word/document.xml")).bufferedReader().readText()
                decode(
                    xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t").replace("<w:br/>", "\n").replace(Regex("<[^>]+>"), "")
                )
            }
        } else f.readText()
        return raw.removePrefix("\uFEFF").lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    private val tableExt = setOf("xlsx", "xlsm", "csv", "tsv")
    private val textExt = setOf("docx", "txt", "md", "log", "json", "xml", "html", "htm")

    private fun cellText(c: XCell?): String = when {
        c == null -> ""
        c.text.isNotEmpty() -> c.text
        c.formula != null -> "=" + c.formula
        else -> ""
    }

    private fun sameValue(a: String, b: String): Boolean {
        if (a.trim() == b.trim()) return true
        val x = a.trim().toDoubleOrNull(); val y = b.trim().toDoubleOrNull()
        return x != null && y != null && x == y
    }

    private class Grid(val headers: List<String>, val rows: List<List<String>>)

    private fun gridOf(sh: XSheet): Grid {
        val cols = sh.lastCol()
        val all = sh.rows.keys.map { r -> (1..cols).map { c -> cellText(sh.get(r, c)) } }.filter { row -> row.any { it.isNotBlank() } }
        if (all.isEmpty()) return Grid(emptyList(), emptyList())
        val head = all[0].mapIndexed { i, h -> h.trim().ifEmpty { "Column ${i + 1}" } }
        return Grid(head, all.drop(1))
    }

    /* ---------------------------- comparing tables ---------------------------- */

    private fun keyed(g: Grid, ki: Int): LinkedHashMap<String, List<String>> {
        val m = LinkedHashMap<String, List<String>>()
        val count = HashMap<String, Int>()
        for (r in g.rows) {
            var k = r.getOrElse(ki) { "" }.trim()
            if (k.isEmpty()) k = "(blank)"
            val n = (count[k] ?: 0) + 1
            count[k] = n
            m[if (n > 1) "$k #$n" else k] = r
        }
        return m
    }

    private fun compareTables(fa: File, fb: File, keyName: String): DiffResult {
        val ba = FileTools.loadTable(fa)
        val bb = FileTools.loadTable(fb)
        val pairs = ArrayList<Pair<XSheet, XSheet>>()
        val notes = ArrayList<String>()
        if (ba.sheets.size == 1 && bb.sheets.size == 1) pairs += ba.sheets[0] to bb.sheets[0]
        else {
            for (sa in ba.sheets) {
                val sb = bb.sheets.firstOrNull { it.name.equals(sa.name, true) }
                if (sb != null) pairs += sa to sb else notes += "Sheet “${sa.name}” is only in ${fa.name}, so it was not compared."
            }
            for (sb in bb.sheets) if (ba.sheets.none { it.name.equals(sb.name, true) }) notes += "Sheet “${sb.name}” is only in ${fb.name}, so it was not compared."
        }
        val sections = ArrayList<DiffSection>()
        var same = 0; var changedRows = 0; var added = 0; var removed = 0; var rowsA = 0; var rowsB = 0
        val multi = pairs.size > 1
        var keyUsed = ""
        for ((sa, sb) in pairs) {
            val ga = gridOf(sa); val gb = gridOf(sb)
            rowsA += ga.rows.size; rowsB += gb.rows.size
            if (ga.headers.isEmpty() || gb.headers.isEmpty()) { notes += "Sheet “${sa.name}” is empty in one of the files."; continue }
            var ki = if (keyName.isBlank()) 0 else ga.headers.indexOfFirst { it.equals(keyName.trim(), true) }
            if (ki < 0) { notes += "There is no column “$keyName” in sheet “${sa.name}”, so its first column was used to match rows."; ki = 0 }
            keyUsed = ga.headers[ki]
            var kb = gb.headers.indexOfFirst { it.equals(ga.headers[ki], true) }
            if (kb < 0) { notes += "Sheet “${sb.name}” in ${fb.name} has no column “${ga.headers[ki]}”, so its first column was used."; kb = 0 }
            val ma = keyed(ga, ki); val mb = keyed(gb, kb)
            val common = ga.headers.mapIndexedNotNull { ai, h ->
                val bi = gb.headers.indexOfFirst { it.equals(h, true) }
                if (bi >= 0) ai to bi else null
            }
            ga.headers.filter { h -> gb.headers.none { it.equals(h, true) } }.forEach { notes += "Column “$it” is only in ${fa.name} (sheet “${sa.name}”)." }
            gb.headers.filter { h -> ga.headers.none { it.equals(h, true) } }.forEach { notes += "Column “$it” is only in ${fb.name} (sheet “${sb.name}”)." }
            val changes = ArrayList<List<String>>()
            val removedRows = ArrayList<List<String>>()
            val addedRows = ArrayList<List<String>>()
            for ((k, ra) in ma) {
                val rb = mb[k]
                if (rb == null) { removedRows += ga.headers.indices.map { ra.getOrElse(it) { "" } }; continue }
                var diff = false
                for ((ai, bi) in common) {
                    val va = ra.getOrElse(ai) { "" }; val vb = rb.getOrElse(bi) { "" }
                    if (!sameValue(va, vb)) { diff = true; changes += listOf(k, ga.headers[ai], va, vb) }
                }
                if (diff) changedRows++ else same++
            }
            for ((k, rb) in mb) if (!ma.containsKey(k)) addedRows += gb.headers.indices.map { rb.getOrElse(it) { "" } }
            removed += removedRows.size; added += addedRows.size
            val suffix = if (multi) " – ${sa.name}" else ""
            sections += DiffSection("Changed cells$suffix", listOf(ga.headers[ki].ifBlank { "Key" }, "Column", "Before (${fa.name})", "After (${fb.name})"), changes, "changed")
            sections += DiffSection("Added rows$suffix", gb.headers, addedRows, "added")
            sections += DiffSection("Removed rows$suffix", ga.headers, removedRows, "removed")
        }
        val stats = listOf(DocStat("Identical rows", same.toString()), DocStat("Changed rows", changedRows.toString()),
            DocStat("Added rows", added.toString()), DocStat("Removed rows", removed.toString()))
        val none = changedRows == 0 && added == 0 && removed == 0
        val summary = if (none) "Both files match: every compared row is the same."
        else "$changedRows row(s) changed, $added row(s) are new in ${fb.name} and $removed row(s) are no longer in it. $same row(s) are identical."
        return DiffResult(
            "Comparison: ${fa.name} vs ${fb.name}",
            "${fa.name} (${rowsA} rows)  →  ${fb.name} (${rowsB} rows)" + (if (keyUsed.isNotBlank()) "  ·  rows matched by “$keyUsed”" else ""),
            stats, summary, if (none) "added" else "changed", sections, notes
        )
    }

    /* ---------------------------- comparing text ---------------------------- */

    /** ' ' = same line, '-' = only in the first file, '+' = only in the second. Each carries its line number in its own file. */
    private class Op(val kind: Char, val text: String, val no: Int)

    private fun diffLines(a: List<String>, b: List<String>): List<Op> {
        val n = a.size; val m = b.size
        val ops = ArrayList<Op>()
        if (n.toLong() * m > 6_000_000L) {
            // very long files: compare line by line as sets instead of a full diff
            val sb = b.toHashSet(); val sa = a.toHashSet()
            a.forEachIndexed { i, l -> ops += Op(if (l in sb) ' ' else '-', l, i + 1) }
            b.forEachIndexed { j, l -> if (l !in sa) ops += Op('+', l, j + 1) }
            return ops
        }
        val w = m + 1
        val dp = IntArray((n + 1) * w)
        for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
            dp[i * w + j] = if (a[i] == b[j]) dp[(i + 1) * w + j + 1] + 1 else maxOf(dp[(i + 1) * w + j], dp[i * w + j + 1])
        }
        var i = 0; var j = 0
        while (i < n && j < m) {
            if (a[i] == b[j]) { ops += Op(' ', a[i], i + 1); i++; j++ }
            else if (dp[(i + 1) * w + j] >= dp[i * w + j + 1]) { ops += Op('-', a[i], i + 1); i++ }
            else { ops += Op('+', b[j], j + 1); j++ }
        }
        while (i < n) { ops += Op('-', a[i], i + 1); i++ }
        while (j < m) { ops += Op('+', b[j], j + 1); j++ }
        return ops
    }

    private fun compareText(fa: File, fb: File): DiffResult {
        val a = textLines(fa); val b = textLines(fb)
        val ops = diffLines(a, b)
        val changed = ArrayList<List<String>>()
        val removedRows = ArrayList<List<String>>()
        val addedRows = ArrayList<List<String>>()
        var same = 0
        var k = 0
        while (k < ops.size) {
            if (ops[k].kind == ' ') { same++; k++; continue }
            val rem = ArrayList<Op>(); val add = ArrayList<Op>()
            while (k < ops.size && ops[k].kind != ' ') { if (ops[k].kind == '-') rem += ops[k] else add += ops[k]; k++ }
            val pairs = minOf(rem.size, add.size)
            for (p in 0 until pairs) changed += listOf(rem[p].no.toString(), rem[p].text, add[p].text)
            for (p in pairs until rem.size) removedRows += listOf(rem[p].no.toString(), rem[p].text)
            for (p in pairs until add.size) addedRows += listOf(add[p].no.toString(), add[p].text)
        }
        val total = a.size + b.size
        val pct = if (total == 0) 100 else Math.round(same * 200.0 / total).toInt()
        val none = changed.isEmpty() && removedRows.isEmpty() && addedRows.isEmpty()
        val stats = listOf(DocStat("Similar", "$pct%"), DocStat("Changed lines", changed.size.toString()),
            DocStat("Added lines", addedRows.size.toString()), DocStat("Removed lines", removedRows.size.toString()))
        val summary = if (none) "Both files match: they have the same text."
        else "The files are $pct% alike. ${changed.size} line(s) were changed, ${addedRows.size} added in ${fb.name} and ${removedRows.size} removed from ${fa.name}."
        val sections = listOf(
            DiffSection("Changed lines", listOf("Line", "Before (${fa.name})", "After (${fb.name})"), changed, "changed"),
            DiffSection("Added lines", listOf("Line in ${fb.name}", "Text"), addedRows, "added"),
            DiffSection("Removed lines", listOf("Line in ${fa.name}", "Text"), removedRows, "removed")
        )
        return DiffResult("Comparison: ${fa.name} vs ${fb.name}", "${fa.name} (${a.size} lines)  →  ${fb.name} (${b.size} lines)",
            stats, summary, if (none) "added" else "changed", sections, emptyList())
    }

    /* ---------------------------- writing the result ---------------------------- */

    private const val DOC_ROW_CAP = 300

    private fun writeDocx(res: DiffResult, f: File) {
        val d = DocxBuilder(res.title, res.subtitle)
        d.stats(res.stats)
        d.callout(res.summary, res.summaryKind)
        var any = false
        for (s in res.sections) {
            if (s.rows.isEmpty()) continue
            any = true
            d.heading("${s.title} (${s.rows.size})")
            d.table(s.headers, s.rows.take(DOC_ROW_CAP), s.kind)
            if (s.rows.size > DOC_ROW_CAP) d.note("… and ${s.rows.size - DOC_ROW_CAP} more not shown here. Ask for the same report as an Excel file to see all of them.")
        }
        if (!any) d.paragraph("Nothing differs between the two files.")
        if (res.notes.isNotEmpty()) { d.heading("Notes"); d.bullets(res.notes.distinct()) }
        d.write(f)
    }

    private fun numeric(t: String) = Regex("-?(0|[1-9][0-9]*)(\\.[0-9]+)?").matches(t)

    private fun writeXlsx(res: DiffResult, f: File) {
        val book = XBook()
        val sum = XSheet("Summary")
        sum.set(1, 1, XCell(res.title, false))
        sum.set(2, 1, XCell(res.subtitle, false))
        sum.set(4, 1, XCell("Result", false)); sum.set(4, 2, XCell("Count", false))
        res.stats.forEachIndexed { i, s -> sum.set(5 + i, 1, XCell(s.label, false)); sum.set(5 + i, 2, XCell(s.value, numeric(s.value))) }
        var r = 6 + res.stats.size
        sum.set(r++, 1, XCell(res.summary, false))
        res.notes.distinct().forEach { sum.set(r++, 1, XCell(it, false)) }
        book.sheets += sum
        for (s in res.sections) {
            if (s.rows.isEmpty()) continue
            val sh = XSheet(s.title)
            s.headers.forEachIndexed { c, h -> sh.set(1, c + 1, XCell(h, false)) }
            s.rows.forEachIndexed { ri, row -> row.forEachIndexed { c, v -> if (v.isNotEmpty()) sh.set(ri + 2, c + 1, XCell(v, numeric(v))) } }
            book.sheets += sh
        }
        Xlsx.write(book, f, true)
    }

    private fun csvLine(cells: List<String>) = cells.joinToString(",") { "\"" + it.replace("\"", "\"\"") + "\"" }

    private fun writeCsv(res: DiffResult, f: File) {
        val sb = StringBuilder("\uFEFF")
        sb.append(csvLine(listOf(res.title))).append("\r\n")
        res.stats.forEach { sb.append(csvLine(listOf(it.label, it.value))).append("\r\n") }
        sb.append(csvLine(listOf(res.summary))).append("\r\n")
        for (s in res.sections) {
            if (s.rows.isEmpty()) continue
            sb.append("\r\n").append(csvLine(listOf(s.title))).append("\r\n").append(csvLine(s.headers)).append("\r\n")
            s.rows.forEach { sb.append(csvLine(it)).append("\r\n") }
        }
        res.notes.distinct().forEach { sb.append("\r\n").append(csvLine(listOf(it))) }
        f.writeText(sb.toString(), Charsets.UTF_8)
    }

    private fun writeTxt(res: DiffResult, f: File) {
        val sb = StringBuilder()
        sb.append(res.title).append('\n').append(res.subtitle).append("\n\n")
        sb.append(res.stats.joinToString("   ") { "${it.label}: ${it.value}" }).append("\n\n").append(res.summary).append('\n')
        for (s in res.sections) {
            if (s.rows.isEmpty()) continue
            sb.append("\n== ${s.title} (${s.rows.size}) ==\n")
            s.rows.forEach { sb.append("- ").append(it.joinToString("  |  ")).append('\n') }
        }
        if (res.notes.isNotEmpty()) { sb.append("\nNotes\n"); res.notes.distinct().forEach { sb.append("- ").append(it).append('\n') } }
        f.writeText(sb.toString(), Charsets.UTF_8)
    }

    /** The kind of report to write: the one asked for, else the same kind as the first file. */
    private fun outFormat(asked: String, fa: File, fb: File): String {
        val want = asked.trim().lowercase(Locale.ROOT).removePrefix(".")
        if (want in setOf("docx", "word", "doc")) return "docx"
        if (want in setOf("xlsx", "excel", "xls")) return "xlsx"
        if (want == "csv") return "csv"
        if (want in setOf("txt", "text")) return "txt"
        return when (fa.extension.lowercase()) {
            "xlsx", "xlsm" -> "xlsx"
            "csv", "tsv" -> "csv"
            "docx" -> "docx"
            "txt", "md", "log", "json", "xml", "html", "htm" -> "txt"
            else -> if (fb.extension.lowercase() in tableExt) "xlsx" else "docx"
        }
    }

    private fun stem(f: File) = f.nameWithoutExtension.take(40)

    fun compare(ctx: Context, a: JSONObject): String {
        val na = a.optString("a").ifBlank { a.optString("file1") }.ifBlank { a.optString("first") }
        val nb = a.optString("b").ifBlank { a.optString("file2") }.ifBlank { a.optString("second") }
        if (na.isBlank() || nb.isBlank()) return "No files named: give the two files to compare as “a” and “b”."
        val fa = AssistantFiles.find(ctx, na) ?: return "No file called “$na” in Downloads, Documents or the Neo Plus folder"
        val fb = AssistantFiles.find(ctx, nb) ?: return "No file called “$nb” in Downloads, Documents or the Neo Plus folder"
        val ea = fa.extension.lowercase(); val eb = fb.extension.lowercase()
        val res = try {
            when {
                ea in tableExt && eb in tableExt -> compareTables(fa, fb, a.optString("key"))
                ea in textExt && eb in textExt -> compareText(fa, fb)
                else -> return "Couldn’t compare ${fa.name} with ${fb.name}: I can compare two tables (.xlsx, .csv, .tsv) or two text files (.docx, .txt, .md). PDFs and pictures can’t be read."
            }
        } catch (e: Exception) { return "Couldn’t compare the files (${e.javaClass.simpleName})." }
        val fmt = outFormat(a.optString("format"), fa, fb)
        var out = a.optString("file").trim().ifBlank { "Comparison - ${stem(fa)} vs ${stem(fb)}" }
        out = out.substringBeforeLast('.', out) + "." + fmt
        val f = AssistantFiles.newFile(ctx, out)
        try {
            when (fmt) {
                "docx" -> writeDocx(res, f)
                "xlsx" -> writeXlsx(res, f)
                "csv" -> writeCsv(res, f)
                else -> writeTxt(res, f)
            }
        } catch (e: Exception) { return "Couldn’t write the report (${e.javaClass.simpleName})." }
        val pub = AssistantFiles.publish(ctx, f, AssistantFiles.mimeOf(f.name))
        return "${res.summary} Report saved as ${f.name} (same kind of file as ${fa.name}) in ${pub ?: f.absolutePath}. (file: ${f.name})"
    }

    /* ---------------------------- word_report ---------------------------- */

    private fun strings(arr: JSONArray?): List<String> =
        if (arr == null) emptyList() else (0 until arr.length()).map { arr.opt(it)?.toString().orEmpty() }

    private fun rowsOf(arr: JSONArray?): List<List<String>> =
        if (arr == null) emptyList() else (0 until arr.length()).map { i ->
            val r = arr.optJSONArray(i)
            if (r != null) strings(r) else listOf(arr.opt(i)?.toString().orEmpty())
        }

    private fun addTable(d: DocxBuilder, t: JSONObject) {
        val rows = rowsOf(t.optJSONArray("rows"))
        if (rows.isEmpty()) return
        d.table(strings(t.optJSONArray("headers")), rows.take(DOC_ROW_CAP), t.optString("kind", "plain"))
        if (rows.size > DOC_ROW_CAP) d.note("… and ${rows.size - DOC_ROW_CAP} more rows not shown.")
    }

    fun wordReport(ctx: Context, a: JSONObject): String {
        val title = a.optString("title").ifBlank { "Report" }
        val d = DocxBuilder(title, a.optString("subtitle"), DocxBuilder.cleanHex(a.optString("accent"), "0A84FF"))
        val tasks = if (a.optBoolean("include_tasks", false)) TaskReports.history(ctx).sortedByDescending { it.at } else emptyList()

        val stats = a.optJSONArray("stats")
        if (stats != null && stats.length() > 0) {
            d.stats((0 until stats.length()).mapNotNull { i ->
                stats.optJSONObject(i)?.let { DocStat(it.optString("label"), it.opt("value")?.toString().orEmpty()) }
            })
        } else if (tasks.isNotEmpty()) {
            val ok = tasks.count { it.ok }
            d.stats(listOf(DocStat("Tasks", tasks.size.toString()), DocStat("Done", ok.toString()), DocStat("Failed", (tasks.size - ok).toString())))
        }
        d.callout(a.optString("summary"), a.optString("summary_kind", "info"))

        val secs = a.optJSONArray("sections")
        if (secs != null) for (i in 0 until secs.length()) {
            val s = secs.optJSONObject(i) ?: continue
            if (s.optString("heading").isNotBlank()) d.heading(s.optString("heading"))
            d.paragraph(s.optString("text"))
            d.bullets(strings(s.optJSONArray("bullets")))
            s.optJSONObject("table")?.let { addTable(d, it) }
            s.optJSONArray("tables")?.let { ts -> for (j in 0 until ts.length()) ts.optJSONObject(j)?.let { addTable(d, it) } }
            d.callout(s.optString("callout"), s.optString("callout_kind", "info"))
        }
        if (tasks.isNotEmpty()) {
            val fmt = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
            d.heading("Finished tasks")
            d.table(listOf("When", "Task", "Result", "Details"),
                tasks.take(DOC_ROW_CAP).map { listOf(fmt.format(Date(it.at)), it.title, if (it.ok) "✓ Done" else "✗ Failed", it.detail) })
        }
        if (secs == null && tasks.isEmpty() && a.optString("summary").isBlank()) return "Couldn’t make the report: there is no content. Give “sections”, a “summary” or set include_tasks."

        var name = a.optString("file").ifBlank { a.optString("name") }.ifBlank { title }.trim()
        name = name.substringBeforeLast('.', name) + ".docx"
        val f = AssistantFiles.newFile(ctx, name)
        try { d.write(f) } catch (e: Exception) { return "Couldn’t write the report (${e.javaClass.simpleName})." }
        val pub = AssistantFiles.publish(ctx, f, AssistantFiles.mimeOf(f.name))
        return "Created the Word report ${f.name}. Saved in ${pub ?: f.absolutePath}. (file: ${f.name})"
    }
}

/* ------------------------------------------------------------------ */
/*  Opening / sharing a file shown in the chat                          */
/* ------------------------------------------------------------------ */

object ChatFiles {
    /** The files the chat can show as cards: where the assistant keeps them, or Downloads/Documents. */
    fun find(ctx: Context, name: String): File? = AssistantFiles.find(ctx, name)

    private fun uriFor(ctx: Context, f: File): Uri? = try {
        val dir = File(ctx.cacheDir, "share").also { it.mkdirs() }
        val copy = File(dir, f.name)
        f.copyTo(copy, overwrite = true)
        FileProvider.getUriForFile(ctx, ctx.packageName + ".files", copy)
    } catch (e: Exception) { null }

    /** Opens the file in whatever app can show it (Word, Excel, ...). False when nothing on the phone can. */
    fun open(ctx: Context, f: File): Boolean {
        val uri = uriFor(ctx, f) ?: return false
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, AssistantFiles.mimeOf(f.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return ctx.safeStart(i)
    }

    fun share(ctx: Context, f: File): Boolean {
        val uri = uriFor(ctx, f) ?: return false
        val send = Intent(Intent.ACTION_SEND).setType(AssistantFiles.mimeOf(f.name))
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri(f.name, uri)
        return ctx.safeStart(Intent.createChooser(send, f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun sizeText(f: File): String {
        val b = f.length()
        return if (b < 1024) "$b B" else if (b < 1024 * 1024) "${b / 1024} KB" else String.format(Locale.US, "%.1f MB", b / 1048576.0)
    }
}
