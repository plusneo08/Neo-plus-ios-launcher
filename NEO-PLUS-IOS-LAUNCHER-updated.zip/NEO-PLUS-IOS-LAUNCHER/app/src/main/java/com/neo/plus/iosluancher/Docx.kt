package com.neo.plus.iosluancher

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** One big number on the row of cards under the title ("12" / "Tasks done"). */
class DocStat(val label: String, val value: String)

/**
 * A small, dependency-free Word (.docx) writer that lays a report out nicely:
 * dark title banner with an accent line, a row of number cards, accent headings, tables with a coloured header row and
 * striped rows, coloured callout boxes and a footer with page numbers.
 * Call the add functions in the order the report should read, then [write].
 */
class DocxBuilder(private val title: String, private val subtitle: String = "", accentHex: String = "0A84FF") {
    private val navy = "0B1F3A"
    private val accent = cleanHex(accentHex, "0A84FF")
    private val body = StringBuilder()
    private val width = 9638            // A4 minus 2 x 2 cm margins, in twentieths of a point

    companion object {
        const val GREEN = "1E9E5A"
        const val RED = "D64545"
        const val AMBER = "E08A00"
        private const val GRID = "D5DDEA"

        fun cleanHex(s: String?, fallback: String): String {
            val h = (s ?: "").trim().removePrefix("#").uppercase(Locale.ROOT)
            return if (Regex("[0-9A-F]{6}").matches(h)) h else fallback
        }

        /** Colour for a kind of table or callout: added / removed / changed / anything else (the accent). */
        fun kindColor(kind: String, accent: String): String = when (kind.lowercase(Locale.ROOT)) {
            "added", "ok", "good" -> GREEN
            "removed", "bad", "error" -> RED
            "changed", "warn", "warning" -> AMBER
            else -> accent
        }

        /** A very light version of [hex], for card and stripe backgrounds. */
        fun tint(hex: String, strength: Double = 0.12): String {
            val r = hex.substring(0, 2).toInt(16); val g = hex.substring(2, 4).toInt(16); val b = hex.substring(4, 6).toInt(16)
            fun mix(c: Int) = (255 - (255 - c) * strength).toInt().coerceIn(0, 255)
            return String.format(Locale.ROOT, "%02X%02X%02X", mix(r), mix(g), mix(b))
        }

        fun esc(s: String): String {
            val sb = StringBuilder(s.length + 8)
            for (ch in s) {
                when {
                    ch == '&' -> sb.append("&amp;")
                    ch == '<' -> sb.append("&lt;")
                    ch == '>' -> sb.append("&gt;")
                    ch == '"' -> sb.append("&quot;")
                    ch.code < 32 && ch != '\t' && ch != '\n' && ch != '\r' -> { }
                    else -> sb.append(ch)
                }
            }
            return sb.toString()
        }
    }

    /* ------------------------------ small XML pieces ------------------------------ */

    private fun run(text: String, size: Int = 21, bold: Boolean = false, italic: Boolean = false, color: String? = null): String {
        val rpr = StringBuilder("<w:rPr><w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:cs=\"Calibri\"/>")
        if (bold) rpr.append("<w:b/>")
        if (italic) rpr.append("<w:i/>")
        if (color != null) rpr.append("<w:color w:val=\"$color\"/>")
        rpr.append("<w:sz w:val=\"$size\"/><w:szCs w:val=\"$size\"/></w:rPr>")
        val parts = text.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val sb = StringBuilder()
        parts.forEachIndexed { i, p ->
            sb.append("<w:r>").append(rpr)
            if (i > 0) sb.append("<w:br/>")
            sb.append("<w:t xml:space=\"preserve\">").append(esc(p)).append("</w:t></w:r>")
        }
        return sb.toString()
    }

    private fun para(
        runs: String, before: Int = 0, after: Int = 100, jc: String? = null, keepNext: Boolean = false,
        borderBottom: String? = null, indentLeft: Int = 0, hanging: Int = 0, outline: Int = -1
    ): String {
        val ppr = StringBuilder("<w:pPr>")
        if (keepNext) ppr.append("<w:keepNext/>")
        if (borderBottom != null) ppr.append("<w:pBdr><w:bottom w:val=\"single\" w:sz=\"10\" w:space=\"3\" w:color=\"$borderBottom\"/></w:pBdr>")
        ppr.append("<w:spacing w:before=\"$before\" w:after=\"$after\" w:line=\"264\" w:lineRule=\"auto\"/>")
        if (indentLeft > 0 || hanging > 0) ppr.append("<w:ind w:left=\"$indentLeft\" w:hanging=\"$hanging\"/>")
        if (jc != null) ppr.append("<w:jc w:val=\"$jc\"/>")
        if (outline >= 0) ppr.append("<w:outlineLvl w:val=\"$outline\"/>")
        ppr.append("</w:pPr>")
        return "<w:p>$ppr$runs</w:p>"
    }

    private fun border(side: String, color: String?, sz: Int = 4): String =
        if (color == null) "<w:$side w:val=\"nil\"/>" else "<w:$side w:val=\"single\" w:sz=\"$sz\" w:space=\"0\" w:color=\"$color\"/>"

    private fun cell(
        w: Int, content: String, fill: String? = null, top: String? = null, right: String? = null, bottom: String? = null,
        left: String? = null, leftSz: Int = 4, bottomSz: Int = 4, pad: String? = null, center: Boolean = true
    ): String {
        val pr = StringBuilder("<w:tcPr><w:tcW w:w=\"$w\" w:type=\"dxa\"/>")
        pr.append("<w:tcBorders>").append(border("top", top)).append(border("left", left, leftSz)).append(border("bottom", bottom, bottomSz)).append(border("right", right)).append("</w:tcBorders>")
        if (fill != null) pr.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$fill\"/>")
        if (pad != null) pr.append(pad)
        if (center) pr.append("<w:vAlign w:val=\"center\"/>")
        pr.append("</w:tcPr>")
        return "<w:tc>$pr$content</w:tc>"
    }

    private fun pad(t: Int, l: Int, b: Int, r: Int) =
        "<w:tcMar><w:top w:w=\"$t\" w:type=\"dxa\"/><w:left w:w=\"$l\" w:type=\"dxa\"/><w:bottom w:w=\"$b\" w:type=\"dxa\"/><w:right w:w=\"$r\" w:type=\"dxa\"/></w:tcMar>"

    private fun tbl(grid: List<Int>, rows: String, borders: String = "<w:tblBorders>${listOf("top", "left", "bottom", "right", "insideH", "insideV").joinToString("") { "<w:$it w:val=\"nil\"/>" }}</w:tblBorders>"): String {
        val sb = StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"${grid.sum()}\" w:type=\"dxa\"/>")
        sb.append(borders)
        sb.append("<w:tblLayout w:type=\"fixed\"/><w:tblCellMar><w:top w:w=\"60\" w:type=\"dxa\"/><w:left w:w=\"110\" w:type=\"dxa\"/><w:bottom w:w=\"60\" w:type=\"dxa\"/><w:right w:w=\"110\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr>")
        sb.append("<w:tblGrid>").append(grid.joinToString("") { "<w:gridCol w:w=\"$it\"/>" }).append("</w:tblGrid>")
        sb.append(rows).append("</w:tbl>")
        return sb.toString()
    }

    private fun gap(after: Int = 120) = "<w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"$after\" w:line=\"120\" w:lineRule=\"exact\"/></w:pPr></w:p>"

    /* ------------------------------ the report ------------------------------ */

    init {
        // Title banner: dark box with an accent line under it
        val inner = para(run(title, 52, bold = true, color = "FFFFFF"), after = if (subtitle.isBlank()) 0 else 60) +
            (if (subtitle.isBlank()) "" else para(run(subtitle, 23, color = "9ADCF7"), after = 0))
        val row = "<w:tr><w:trPr><w:cantSplit/></w:trPr>" +
            cell(width, inner, fill = navy, bottom = accent, bottomSz = 36, pad = pad(300, 360, 300, 360)) + "</w:tr>"
        body.append(tbl(listOf(width), row))
        val stamp = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        body.append(para(run("Prepared by NEO PLUS  ·  $stamp", 18, color = "6B7A90"), before = 100, after = 160))
    }

    /** A row of number cards (up to 5): big value, small label. */
    fun stats(list: List<DocStat>, color: String? = null) {
        val items = list.take(5)
        if (items.isEmpty()) return
        val cw = width / items.size
        val grid = List(items.size) { if (it == items.lastIndex) width - cw * (items.size - 1) else cw }
        val fill = tint(color ?: accent, 0.10)
        val rowCells = items.mapIndexed { i, s ->
            val c = para(run(s.value, 44, bold = true, color = color ?: accent), after = 0, jc = "center") +
                para(run(s.label, 18, color = "44546A"), after = 0, jc = "center")
            cell(grid[i], c, fill = fill, top = "FFFFFF", right = "FFFFFF", bottom = "FFFFFF", left = "FFFFFF", leftSz = 36, pad = pad(140, 80, 140, 80))
        }.joinToString("")
        body.append(tbl(grid, "<w:tr><w:trPr><w:cantSplit/></w:trPr>$rowCells</w:tr>"))
        body.append(gap(160))
    }

    fun heading(text: String) {
        body.append(para(run(text, 30, bold = true, color = navy), before = 280, after = 120, keepNext = true, borderBottom = accent, outline = 0))
    }

    fun subheading(text: String, color: String? = null) {
        body.append(para(run(text, 24, bold = true, color = color ?: navy), before = 180, after = 80, keepNext = true, outline = 1))
    }

    fun paragraph(text: String) {
        if (text.isBlank()) return
        body.append(para(run(text, 21, color = "1F2937"), after = 120))
    }

    fun note(text: String) {
        if (text.isBlank()) return
        body.append(para(run(text, 18, italic = true, color = "6B7A90"), after = 100))
    }

    fun bullets(items: List<String>) {
        for (t in items) {
            if (t.isBlank()) continue
            body.append(para(run("•", 21, bold = true, color = accent) + "<w:r><w:tab/></w:r>" + run(t, 21, color = "1F2937"), after = 60, indentLeft = 360, hanging = 360))
        }
    }

    /** A box with a thick coloured edge on the left and a light background: for the key finding. */
    fun callout(text: String, kind: String = "info") {
        if (text.isBlank()) return
        val c = kindColor(kind, accent)
        val row = "<w:tr><w:trPr><w:cantSplit/></w:trPr>" +
            cell(width, para(run(text, 22, color = "1F2937"), after = 0), fill = tint(c, 0.12), left = c, leftSz = 48, pad = pad(130, 200, 130, 200)) + "</w:tr>"
        body.append(tbl(listOf(width), row))
        body.append(gap(140))
    }

    /** A table with a coloured header row and striped rows. [kind] (added / removed / changed) picks the colour. Cells starting with ✓ or ✗ are green or red. */
    fun table(headers: List<String>, rows: List<List<String>>, kind: String = "plain") {
        val cols = maxOf(headers.size, rows.maxOfOrNull { it.size } ?: 0)
        if (cols == 0) return
        val c = kindColor(kind, accent)
        // column widths follow how much text each column holds
        val weights = (0 until cols).map { i ->
            var m = (headers.getOrNull(i) ?: "").length
            for (r in rows.take(60)) m = maxOf(m, (r.getOrNull(i) ?: "").length)
            m.coerceIn(6, 48)
        }
        val total = weights.sum()
        val grid = ArrayList<Int>()
        var used = 0
        weights.forEachIndexed { i, wt ->
            val w = if (i == cols - 1) width - used else (width.toLong() * wt / total).toInt().coerceAtLeast(700)
            grid += w; used += w
        }
        // the last column absorbs rounding; make sure it did not go negative when many columns hit the minimum
        if (grid.last() < 700) { val f = width.toDouble() / grid.sum(); for (i in grid.indices) grid[i] = (grid[i] * f).toInt() }
        val sb = StringBuilder()
        if (headers.isNotEmpty()) {
            sb.append("<w:tr><w:trPr><w:cantSplit/><w:tblHeader/></w:trPr>")
            for (i in 0 until cols) sb.append(cell(grid[i], para(run(headers.getOrNull(i) ?: "", 19, bold = true, color = "FFFFFF"), after = 0), fill = c))
            sb.append("</w:tr>")
        }
        rows.forEachIndexed { ri, r ->
            sb.append("<w:tr><w:trPr><w:cantSplit/></w:trPr>")
            val fill = if (ri % 2 == 1) tint(c, 0.07) else "FFFFFF"
            for (i in 0 until cols) {
                val t = (r.getOrNull(i) ?: "").let { if (it.length > 600) it.take(600) + "…" else it }
                val col = when { t.startsWith("✓") -> GREEN; t.startsWith("✗") -> RED; else -> "1F2937" }
                sb.append(cell(grid[i], para(run(t, 19, bold = t.startsWith("✓") || t.startsWith("✗"), color = col), after = 0), fill = fill, bottom = GRID, center = false))
            }
            sb.append("</w:tr>")
        }
        body.append(tbl(grid, sb.toString()))
        body.append(gap(160))
    }

    /* ------------------------------ writing the file ------------------------------ */

    fun write(file: File) {
        val ns = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\""
        val sect = "<w:sectPr><w:footerReference w:type=\"default\" r:id=\"rId2\"/><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1000\" w:right=\"1134\" w:bottom=\"1100\" w:left=\"1134\" w:header=\"500\" w:footer=\"500\" w:gutter=\"0\"/></w:sectPr>"
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:document $ns><w:body>$body$sect</w:body></w:document>"
        val footer = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:ftr $ns><w:p><w:pPr>" +
            "<w:pBdr><w:top w:val=\"single\" w:sz=\"4\" w:space=\"6\" w:color=\"$GRID\"/></w:pBdr><w:tabs><w:tab w:val=\"right\" w:pos=\"$width\"/></w:tabs></w:pPr>" +
            run("NEO PLUS report", 17, color = "6B7A90") + "<w:r><w:tab/></w:r>" + run("Page ", 17, color = "6B7A90") +
            "<w:fldSimple w:instr=\" PAGE \">" + run("1", 17, color = "6B7A90") + "</w:fldSimple>" + run(" of ", 17, color = "6B7A90") +
            "<w:fldSimple w:instr=\" NUMPAGES \">" + run("1", 17, color = "6B7A90") + "</w:fldSimple></w:p></w:ftr>"
        val styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><w:styles $ns><w:docDefaults><w:rPrDefault><w:rPr>" +
            "<w:rFonts w:ascii=\"Calibri\" w:hAnsi=\"Calibri\" w:cs=\"Calibri\" w:eastAsia=\"Calibri\"/><w:sz w:val=\"21\"/><w:szCs w:val=\"21\"/><w:lang w:val=\"en-US\"/></w:rPr></w:rPrDefault>" +
            "<w:pPrDefault><w:pPr><w:spacing w:after=\"100\" w:line=\"264\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>" +
            "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/><w:qFormat/></w:style></w:styles>"
        val core = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" " +
            "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
            "<dc:title>${esc(title)}</dc:title><dc:creator>NEO PLUS</dc:creator></cp:coreProperties>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>" +
            "<Override PartName=\"/word/footer1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml\"/>" +
            "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/></Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/></Relationships>"
        val docRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/footer\" Target=\"footer1.xml\"/></Relationships>"
        ZipOutputStream(file.outputStream().buffered()).use { z ->
            fun put(path: String, text: String) { z.putNextEntry(ZipEntry(path)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", types)
            put("_rels/.rels", rels)
            put("word/document.xml", doc)
            put("word/_rels/document.xml.rels", docRels)
            put("word/styles.xml", styles)
            put("word/footer1.xml", footer)
            put("docProps/core.xml", core)
        }
    }
}
