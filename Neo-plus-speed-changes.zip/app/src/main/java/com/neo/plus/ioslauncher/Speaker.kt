package com.neo.plus.ioslauncher

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.math.sqrt
import android.util.LruCache
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Guesses what language a text is in. Chichewa (Chinyanja) is spelled the way it sounds and uses a small set of very
 * common words that do not exist in English, so counting them is a reliable signal for short messages.
 */
object LangGuess {
    private val chichewa = setOf(
        "muli", "bwanji", "zikomo", "kwambiri", "inde", "ayi", "chonde", "ndikufuna", "ndili", "uthenga", "moni", "pepani",
        "wanu", "watumiza", "tsopano", "lero", "mawa", "dzulo", "ndalama", "chakudya", "abambo", "amayi", "ndiwerenge",
        "werengani", "mukufuna", "tiyeni", "bwino", "koma", "tikuwonana", "madzulo", "masana", "ndipo", "kapena", "ntchito",
        "kunyumba", "galimoto", "sukulu", "wabwino", "ndiwe", "iwe", "inu", "ife", "iwo", "kodi", "chiyani", "liti", "kuti",
        "ndani", "ndikupita", "ndikubwera", "ndatumiza", "walandira", "analandira", "watumizidwa", "ndikuthokozani",
        "mwadzuka", "mwauka", "mwaswera", "ndili bwino", "zili bwanji", "tumizani", "ndithu", "mnzanga", "bambo", "mayi",
        "mwana", "anthu", "pano", "uko", "komwe", "chifukwa", "ndiye", "tidzakumana", "mutipatse", "ndikukuyembekezera"
    )

    /** Returns the Chichewa locale when the text looks Chichewa, otherwise null (use the phone's language). */
    fun detect(text: String): Locale? {
        val words = text.lowercase(Locale.ROOT).split(Regex("[^\\p{L}']+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return null
        val hits = words.count { it in chichewa }
        val strong = hits >= 2 || (hits == 1 && words.size <= 3)
        return if (strong) Locale("ny") else null
    }

    fun isChichewa(text: String) = detect(text) != null
}

/**
 * A natural, human-sounding voice from Google's Gemini speech models (needs a Gemini key). Falls back to the phone's
 * own voice when there is no key, no internet, or the text is in a language the cloud voice can't be trusted with.
 */
object NaturalVoice {
    class Cfg(val key: String, val voice: String)

    /** Gemini speech voices by gender. The chosen gender never uses a voice from the other list. */
    val FEMALE = listOf("Aoede", "Kore")
    val MALE = listOf("Charon", "Orus")

    /** The chosen voice first, then a second voice of the SAME gender to try if the first one fails. */
    private fun sameGender(voice: String): List<String> {
        val list = if (voice in MALE) MALE else FEMALE
        return listOf(voice) + list.filter { it != voice }
    }

    private val models = listOf("gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts")
    const val RATE = 24000

    fun config(ctx: Context): Cfg? {
        val p = ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE)
        migrateToGeminiOnly(p)
        KeyPool.attach(ctx)
        val key = p.getString("key", "") ?: ""
        if (key.isBlank()) return null
        val male = (p.getString("voice_gender", "female") ?: "female") == "male"
        return Cfg(key.trim(), if (male) MALE[0] else FEMALE[0])
    }

    fun gender(ctx: Context): String =
        ctx.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getString("voice_gender", "female") ?: "female"

    /** Voices already made this session, so a repeated sentence ("Calling Mum") plays at once. About 8 MB at most. */
    private val cache = object : LruCache<String, ByteArray>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray) = value.size
    }

    /** "<key>|<model>" -> epoch ms until which that key is known to have NO quota ("limit: 0") on that voice model. */
    private val noAccess = java.util.concurrent.ConcurrentHashMap<String, Long>()

    @Volatile private var warmed = false

    /**
     * Called once when the orb starts. Opens the connection to Google ahead of time (saves the TLS handshake on the first
     * real reply) and makes the most common short replies, so "Yes?" after the wake phrase plays at once.
     */
    fun prewarm(key: String, voice: String) {
        if (warmed) return
        warmed = true
        try {
            val c = URL("https://generativelanguage.googleapis.com/").openConnection() as HttpURLConnection
            c.connectTimeout = 4_000
            c.readTimeout = 4_000
            try { c.responseCode; (c.errorStream ?: c.inputStream)?.use { it.readBytes() } } catch (e: Exception) { }
            c.disconnect()
        } catch (e: Exception) { }
        for (t in listOf("Yes?", "Okay.")) {
            try { synth(key, t, voice, fast = true) } catch (e: Exception) { }
        }
    }

    /** Raw 16-bit mono PCM at 24 kHz. */
    fun synth(key: String, text: String, voice: String, fast: Boolean = false): ByteArray {
        val ck = voice + "|" + text
        cache.get(ck)?.let { return it }
        // fast = the first piece of a reply: the lighter model is tried first so the first words start sooner
        val order = if (fast) models.reversed() else models
        var last: Exception? = null
        val now = System.currentTimeMillis()
        // A different voice never fixes a quota problem, so a model that is out of quota / not allowed is skipped for
        // every voice, and a rejected key stops the whole attempt at once (it used to try all 4 combinations).
        val skip = HashSet<String>()
        for (v in sameGender(voice)) {
            for (m in order) {
                if (m in skip || (noAccess[key.hashCode().toString() + "|" + m] ?: 0L) > now) continue
                if (Thread.currentThread().isInterrupted) throw InterruptedException()
                try {
                    val pcm = polish(KeyPool.run(key, m) { k -> synthWith(m, k, text, v) })
                    cache.put(ck, pcm)
                    return pcm
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: KeyLimitException) {
                    last = e; skip += m
                    if (e.noAccess) noAccess[key.hashCode().toString() + "|" + m] = System.currentTimeMillis() + 6 * 3_600_000L
                } catch (e: Llm.LlmException) {
                    last = e
                    if (e.message?.startsWith("The API key was rejected") == true) throw e
                } catch (e: Exception) { last = e }
            }
        }
        throw last ?: Exception("No voice")
    }

    /**
     * The newer Gemini voice models (gemini-3.8-*-tts) return a WAV file (RIFF header) by default, not headerless PCM.
     * The header was being played as audio and the rest of the code assumes 24 kHz mono 16-bit, so strip the header and,
     * if the file is a different rate or stereo, convert it. Headerless PCM (older models) passes through unchanged.
     */
    private fun toPcm24k(raw: ByteArray): ByteArray {
        if (raw.size < 44 || raw[0] != 'R'.code.toByte() || raw[1] != 'I'.code.toByte() || raw[2] != 'F'.code.toByte() || raw[3] != 'F'.code.toByte()) return raw
        fun le32(o: Int) = (raw[o].toInt() and 0xFF) or ((raw[o + 1].toInt() and 0xFF) shl 8) or ((raw[o + 2].toInt() and 0xFF) shl 16) or ((raw[o + 3].toInt() and 0xFF) shl 24)
        fun le16(o: Int) = (raw[o].toInt() and 0xFF) or ((raw[o + 1].toInt() and 0xFF) shl 8)
        var rate = RATE
        var channels = 1
        var pos = 12
        var start = -1
        var len = 0
        while (pos + 8 <= raw.size) {
            val id = String(raw, pos, 4, Charsets.US_ASCII)
            val size = le32(pos + 4)
            if (id == "fmt " && pos + 8 + 16 <= raw.size) {
                channels = le16(pos + 10).coerceAtLeast(1)
                rate = le32(pos + 12).takeIf { it in 8000..96000 } ?: RATE
            }
            if (id == "data") {
                start = pos + 8
                // streamed files can carry 0 / 0xFFFFFFFF as the size: take everything that is left
                len = if (size <= 0 || start + size > raw.size) raw.size - start else size
                break
            }
            if (size < 0 || pos + 8 + size > raw.size) break
            pos += 8 + size + (size and 1)
        }
        if (start < 0) { start = 44; len = raw.size - 44 }
        len -= len % (2 * channels)
        if (len <= 0) return ByteArray(0)
        // mix down to mono
        val frames = len / (2 * channels)
        val mono = ShortArray(frames)
        for (f in 0 until frames) {
            var sum = 0
            for (c in 0 until channels) {
                val o = start + (f * channels + c) * 2
                sum += (raw[o].toInt() and 0xFF) or (raw[o + 1].toInt() shl 8)
            }
            mono[f] = (sum / channels).toShort()
        }
        // resample (linear) to 24 kHz when needed
        val out = if (rate == RATE) mono else {
            val n = (frames.toLong() * RATE / rate).toInt()
            ShortArray(n) { i ->
                val p = i.toDouble() * rate / RATE
                val i0 = p.toInt().coerceAtMost(frames - 1)
                val i1 = (i0 + 1).coerceAtMost(frames - 1)
                val fr = p - i0
                (mono[i0] * (1 - fr) + mono[i1] * fr).toInt().toShort()
            }
        }
        val res = ByteArray(out.size * 2)
        for (i in out.indices) { res[i * 2] = (out[i].toInt() and 0xFF).toByte(); res[i * 2 + 1] = (out[i].toInt() shr 8).toByte() }
        return res
    }

    private fun synthWith(model: String, key: String, text: String, voice: String): ByteArray {
        // Only the words to be spoken go to the voice model. An instruction such as "say this naturally" in the same
        // text is read out loud by the model ("speak in natural human voice..."), so there is none. The voice name
        // already decides how it sounds. Ending with a full stop stops the model from inventing a trailing sound.
        val spoken = text.trim().let { if (it.isNotEmpty() && it.last() !in ".!?…\"”)") it + "." else it }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", spoken)))))
            .put(
                "generationConfig", JSONObject()
                    .put("responseModalities", JSONArray().put("AUDIO"))
                    .put(
                        "speechConfig", JSONObject().put(
                            "voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice))
                        )
                    )
            ).toString()
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 6_000
            c.readTimeout = 25_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) {
                val err = try { c.errorStream?.bufferedReader()?.use { it.readText() } ?: "" } catch (e: Exception) { "" }
                KeyPool.limitFrom(code, err)?.let { throw it } // out of quota: the next key takes over
                if (KeyPool.rejectedFrom(code, err)) throw Llm.LlmException("The API key was rejected ($code)")
                throw Exception("Voice request failed ($code)")
            }
            val res = c.inputStream.bufferedReader().use { it.readText() }
            // The audio is not always in the first part of the reply: look through every part of every candidate.
            var data: String? = null
            val cands = JSONObject(res).optJSONArray("candidates")
            loop@ for (ci in 0 until (cands?.length() ?: 0)) {
                val parts = cands!!.optJSONObject(ci)?.optJSONObject("content")?.optJSONArray("parts") ?: continue
                for (pi in 0 until parts.length()) {
                    val d = parts.optJSONObject(pi)?.optJSONObject("inlineData")?.optString("data").orEmpty()
                    if (d.isNotEmpty()) { data = d; break@loop }
                }
            }
            if (data == null) throw Exception("No audio in reply")
            val pcm = toPcm24k(Base64.decode(data, Base64.DEFAULT))
            if (pcm.size < 2000) throw Exception("Empty audio")
            return pcm
        } finally {
            c.disconnect()
        }
    }

    /**
     * Takes the hiss out of the whole spoken piece, not just its tail. The voice model leaves a steady high-frequency
     * hiss under the words and between them. Three gentle steps, all done in memory in a few milliseconds:
     *  1. a 60 Hz high-pass (rumble, DC offset),
     *  2. a 7 kHz low-pass (hiss lives up there; speech keeps its clarity, "s" and "t" stay),
     *  3. a soft noise gate: stretches that are only noise are turned down to about a third (not to silence, so the voice
     *     never "pumps"), opening 3 ms before a word and closing slowly after it.
     * Pieces that are already clean or very short are passed through untouched.
     */
    internal fun denoise(pcm: ByteArray): ByteArray {
        val n = pcm.size / 2
        val frame = RATE / 200 // 5 ms
        if (n < frame * 20) return pcm
        val x = DoubleArray(n) { ((pcm[2 * it + 1].toInt() shl 8) or (pcm[2 * it].toInt() and 0xFF)).toShort().toDouble() }

        // biquad: direct form I, applied in place
        fun biquad(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
            var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
            val nb0 = b0 / a0; val nb1 = b1 / a0; val nb2 = b2 / a0; val na1 = a1 / a0; val na2 = a2 / a0
            for (i in x.indices) {
                val v = x[i]
                val y = nb0 * v + nb1 * x1 + nb2 * x2 - na1 * y1 - na2 * y2
                x2 = x1; x1 = v; y2 = y1; y1 = y
                x[i] = y
            }
        }
        fun lowHigh(fc: Double, high: Boolean) {
            val w = 2.0 * Math.PI * fc / RATE
            val c = Math.cos(w); val al = Math.sin(w) / (2.0 * 0.7071)
            if (high) biquad((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
            else biquad((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
        }
        lowHigh(60.0, true)
        lowHigh(7000.0, false)

        // soft noise gate
        val frames = n / frame
        val rms = DoubleArray(frames)
        for (f in 0 until frames) {
            var acc = 0.0
            for (i in f * frame until (f + 1) * frame) acc += x[i] * x[i]
            rms[f] = sqrt(acc / frame)
        }
        val sorted = rms.sorted()
        val floor = sorted[((frames - 1) * 0.08).toInt()].coerceAtLeast(8.0)
        val speechLevel = sorted[((frames - 1) * 0.90).toInt()]
        if (speechLevel > floor * 3.0) {
            val thr = maxOf(floor * 2.4, speechLevel * 0.05)
            var g = 1.0
            val opn = 1.0 - Math.exp(-1.0 / (RATE * 0.003))   // 3 ms to open
            val cls = 1.0 - Math.exp(-1.0 / (RATE * 0.060))  // 60 ms to close
            for (f in 0 until frames) {
                // open when this frame or a neighbour is above the threshold (so a word start is never clipped)
                val loud = rms[f] >= thr || (f > 0 && rms[f - 1] >= thr) || (f + 1 < frames && rms[f + 1] >= thr)
                val target = if (loud) 1.0 else 0.33
                for (i in f * frame until (f + 1) * frame) {
                    g += (target - g) * (if (target > g) opn else cls)
                    x[i] *= g
                }
            }
        }
        val out = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = x[i].toInt().coerceIn(-32768, 32767)
            out[2 * i] = (v and 0xFF).toByte(); out[2 * i + 1] = (v shr 8).toByte()
        }
        return out
    }

    /**
     * Cleans the end of every spoken piece. The voice model adds a hissy / static tail after the last word (it sounds
     * like a radio switching off). Walking back from the end, every frame that is quiet, or noise-like (hiss: lots of
     * zero crossings, little energy), is cut. Only 30 ms is kept after the last real word, then a quick smooth fade
     * out, and 200 ms of true silence is added so the player never stops on a sound.
     */
    internal fun polish(pcmIn: ByteArray): ByteArray {
        val pcm = denoise(pcmIn)
        val n = pcm.size / 2
        val frame = RATE / 200 // 5 ms
        if (n < frame * 20) return pcm
        val s = ShortArray(n) { ((pcm[2 * it + 1].toInt() shl 8) or (pcm[2 * it].toInt() and 0xFF)).toShort() }
        val frames = n / frame
        val rms = DoubleArray(frames)
        val zcr = DoubleArray(frames)
        for (f in 0 until frames) {
            var acc = 0.0
            var cross = 0
            val from = f * frame
            for (i in from until from + frame) {
                acc += s[i].toDouble() * s[i]
                if (i > from && ((s[i] >= 0) != (s[i - 1] >= 0))) cross++
            }
            rms[f] = sqrt(acc / frame)
            zcr[f] = cross.toDouble() / frame
        }
        val ref = rms.sorted()[((frames - 1) * 0.9).toInt()]
        var end = n
        if (ref > 150) {
            // Speech = three frames in a row (15 ms) that are loud enough AND smooth (few zero crossings). Hiss, static
            // and isolated crackle never pass this test, including low rumble and clicks that the old rule counted as
            // "voice" and therefore kept. Everything after the last speech frame is cut, keeping 110 ms so word endings
            // such as "s" and "t" are not clipped.
            fun speech(f: Int) = rms[f] >= ref * 0.30 && zcr[f] < 0.20
            var last = -1
            for (f in frames - 1 downTo 2) if (speech(f) && speech(f - 1) && speech(f - 2)) { last = f; break }
            if (last >= 0) end = min(n, (last + 1) * frame + RATE * 110 / 1000)
        }
        val fadeOut = min(end, RATE * 70 / 1000)
        for (i in 0 until fadeOut) {
            val idx = end - 1 - i
            val g = i.toFloat() / fadeOut
            s[idx] = (s[idx] * g * g).toInt().toShort()
        }
        val fadeIn = min(end, RATE * 6 / 1000)
        for (i in 0 until fadeIn) s[i] = (s[i] * (i.toFloat() / fadeIn)).toInt().toShort()
        val pad = RATE * 200 / 1000
        val out = ByteArray((end + pad) * 2) // the padding stays zero = silence
        for (i in 0 until end) { out[2 * i] = (s[i].toInt() and 0xFF).toByte(); out[2 * i + 1] = (s[i].toInt() shr 8).toByte() }
        return out
    }
}

/**
 * One shared text-to-speech engine. Speaks sentence by sentence so the floating orb can show each sentence as a
 * subtitle while it is spoken. Chichewa is spoken with a Chichewa voice if the phone has one; most phones do not,
 * so it falls back to Swahili (closest widely available pronunciation), then to the phone's language.
 */
object Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var initFailed = false
    private var queued: (() -> Unit)? = null
    private var queuedGiveUp: (() -> Unit)? = null

    @Volatile
    var speaking = false
        private set

    /** Set when the spoken language had to be replaced by a different voice (shown to the user once). */
    @Volatile
    var voiceNote: String = ""
        private set

    private var batch = 0L
    private val sentences = HashMap<String, Pair<String, Boolean>>() // utteranceId -> (sentence, isLast)
    private var onSentence: ((String) -> Unit)? = null
    private var onFinished: (() -> Unit)? = null

    private var appCtx: Context? = null
    @Volatile private var naturalToken = 0L
    private var track: AudioTrack? = null
    private val pool = Executors.newFixedThreadPool(5)

    /** Warms up the cloud voice in the background (once per run). Safe to call when there is no key. */
    /** Makes the voice for a whole text ahead of time (the wake-up summary), so it starts at once when it is spoken. Blocks until done. */
    fun prewarmSpeech(ctx: Context, text: String) {
        val cfg = NaturalVoice.config(ctx.applicationContext) ?: return
        if (text.isBlank() || LangGuess.isChichewa(text)) return
        chunkP(splitP(text)).forEachIndexed { i, c ->
            try { NaturalVoice.synth(cfg.key, c.first, cfg.voice, fast = i == 0) } catch (e: Exception) { }
        }
    }

    fun prewarm(ctx: Context) {
        val cfg = NaturalVoice.config(ctx.applicationContext) ?: return
        pool.execute { try { NaturalVoice.prewarm(cfg.key, cfg.voice) } catch (e: Exception) { } }
    }

    /**
     * Gemini voice for EVERYTHING (default on): replies, command answers, announcements, and also text that looks like Chichewa.
     * The phone's own voice is used only when there is no Gemini key, or when the Gemini voice failed twice in a row (and then a
     * short message says why). Set "gemini_always" to false in the "neo_assistant" preferences to bring the old behaviour back.
     */
    @Suppress("UNUSED_PARAMETER")
    fun geminiAlways(ctx: Context): Boolean = true

    @Volatile private var lastFallbackToast = 0L

    private fun fallbackNotice(app: Context, why: String) {
        val now = System.currentTimeMillis()
        if (now - lastFallbackToast < 60_000L) return
        lastFallbackToast = now
        main.post {
            try { android.widget.Toast.makeText(app, "Gemini voice didn’t answer (" + why.take(90) + "), so the phone’s voice read this.", android.widget.Toast.LENGTH_LONG).show() } catch (e: Exception) { }
        }
    }

    /** [natural] is kept for old call sites: the voice is chosen by the settings above. */
    fun speak(ctx: Context, text: String, onStart: ((String) -> Unit)? = null, onDone: (() -> Unit)? = null, natural: Boolean = true) {
        val app = ctx.applicationContext
        appCtx = app
        main.post {
            if (text.isBlank()) { onDone?.invoke(); return@post }
            // One voice for everything: when a Gemini key exists, command answers and announcements use the same Gemini
            // voice as chat replies (the phone's own voice is a different speaker and sounded like a second person).
            val cfg = NaturalVoice.config(app)
            if (cfg != null && (geminiAlways(app) || !LangGuess.isChichewa(text))) speakNatural(app, text, cfg, onStart, onDone)
            else speakSystem(app, text, onStart, onDone)
        }
    }

    private fun speakSystem(app: Context, text: String, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        // Never talk over a Gemini voice that is still playing (two voices at once).
        naturalToken++
        try { track?.pause(); track?.flush() } catch (e: Exception) { }
        if (ready) {
            say(text, onStart, onDone)
        } else if (initFailed) {
            onStart?.invoke(text)
            main.postDelayed({ onDone?.invoke() }, 1500L + text.length * 45L)
        } else {
            queued = { say(text, onStart, onDone) }
            queuedGiveUp = { onStart?.invoke(text); main.postDelayed({ onDone?.invoke() }, 1500L + text.length * 45L) }
            if (tts == null) init(app)
        }
    }

    /**
     * Joins short sentences so the voice keeps its natural flow; each chunk is one subtitle. The first chunk is short
     * so the voice can start quickly; the rest are longer because they are made while the first one is playing.
     * A chunk never runs across the end of a message (line): the flag says "this chunk ends a message".
     */
    private fun chunkP(items: List<Pair<String, Boolean>>): List<Pair<String, Boolean>> {
        // A long first sentence is cut at its first comma / colon so the first piece to make (and hear) is short.
        val sentences = items.toMutableList()
        if (sentences.isNotEmpty() && sentences[0].first.length > 70) {
            val first = sentences[0].first
            val m = Regex("[,;:] ").findAll(first).firstOrNull { it.range.first in 18..70 }
            if (m != null) {
                val endsMessage = sentences[0].second
                sentences[0] = first.substring(0, m.range.first + 1).trim() to false
                sentences.add(1, first.substring(m.range.last + 1).trim() to endsMessage)
            }
        }
        val out = mutableListOf<Pair<String, Boolean>>()
        var cur = ""
        for ((sentence, endsMessage) in sentences) {
            val limit = if (out.isEmpty()) 40 else 220
            if (cur.isNotEmpty() && cur.length + sentence.length > limit) { out += cur to false; cur = sentence }
            else cur = if (cur.isEmpty()) sentence else "$cur $sentence"
            if (endsMessage) { out += cur to true; cur = "" }
        }
        if (cur.isNotEmpty()) out += cur to false
        return out
    }

    /** How long the voice stays quiet after a piece of speech: it depends on the punctuation it ended with, and is longer when a message ended. */
    private fun gapAfter(piece: String, endsMessage: Boolean): Long {
        val base = when (piece.trimEnd().lastOrNull()) {
            '.' -> 200L
            '!', '?' -> 240L
            '…' -> 350L
            ':', ';' -> 150L
            ',' -> 100L
            else -> 0L
        }
        return if (endsMessage) base + 250L else base
    }

    /** Silence between two pieces; ends at once when the speech is stopped. */
    private fun pauseFor(ms: Long, my: Long) {
        var left = ms
        while (left > 0 && naturalToken == my) {
            val step = if (left < 25L) left else 25L
            try { Thread.sleep(step) } catch (e: Exception) { return }
            left -= step
        }
    }

    private fun speakNatural(app: Context, text: String, cfg: NaturalVoice.Cfg, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        try { tts?.stop() } catch (e: Exception) { }
        try { track?.pause(); track?.flush() } catch (e: Exception) { }
        sentences.clear()
        val chunks = chunkP(splitP(text))
        if (chunks.isEmpty()) { onDone?.invoke(); return }
        val my = ++naturalToken
        speaking = true
        // Every chunk is requested at once (the pool runs several together), so while one plays the next are ready.
        val jobs: List<Future<ByteArray>> = chunks.mapIndexed { i, c -> pool.submit<ByteArray> { NaturalVoice.synth(cfg.key, c.first, cfg.voice, fast = i == 0) } }
        pool.execute {
            try {
                for (i in chunks.indices) {
                    if (naturalToken != my) { jobs.forEach { it.cancel(true) }; return@execute }
                    // The first words wait up to 9 s for the Gemini voice (5 s when "gemini_always" is off); one more try before the phone's voice.
                    val always = geminiAlways(app)
                    var why = ""
                    var pcm = try { jobs[i].get(if (i == 0) (if (always) 9L else 5L) else 25L, TimeUnit.SECONDS) } catch (e: Exception) { why = e.cause?.message ?: e.message ?: e.javaClass.simpleName; null }
                    if (pcm == null && always && naturalToken == my) {
                        pcm = try {
                            pool.submit<ByteArray> { NaturalVoice.synth(cfg.key, chunks[i].first, cfg.voice, fast = i == 0) }.get(10L, TimeUnit.SECONDS)
                        } catch (e: Exception) { why = e.cause?.message ?: e.message ?: why; null }
                    }
                    if (naturalToken != my) { jobs.forEach { it.cancel(true) }; return@execute }
                    if (pcm == null) { // cloud voice failed twice: finish with the phone's own voice
                        jobs.forEach { it.cancel(true) }
                        fallbackNotice(app, why.ifBlank { "no answer in time" })
                        val rest = chunks.subList(i, chunks.size).joinToString(" ") { it.first }
                        main.post { if (naturalToken == my) { speaking = false; speakSystem(app, rest, onStart, onDone) } }
                        return@execute
                    }
                    main.post { if (naturalToken == my) onStart?.invoke(chunks[i].first) }
                    playPcm(pcm, my)
                    // stop where the punctuation is, and a little longer where one message ends and the next begins
                    if (i < chunks.lastIndex) pauseFor(gapAfter(chunks[i].first, chunks[i].second), my)
                }
                main.post { if (naturalToken == my) { speaking = false; onDone?.invoke() } }
            } catch (e: Exception) {
                main.post { if (naturalToken == my) { speaking = false; onDone?.invoke() } }
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /*  Live speech: speak a reply while it is still being written          */
    /* ------------------------------------------------------------------ */

    private class LiveItem(val text: String, val job: Future<ByteArray>?) // job == null: the reply is complete

    @Volatile private var liveQ: java.util.concurrent.LinkedBlockingQueue<LiveItem>? = null
    @Volatile private var liveCfg: NaturalVoice.Cfg? = null
    @Volatile private var liveToken = 0L
    private val liveLock = Any()
    private var liveEnded = false
    @Volatile private var liveFedOnce = false   // reset by liveStart: the first piece of a live reply uses the fast voice model
    private var liveFailed = false              // guarded by liveLock
    private val liveRest = StringBuilder()      // text the Gemini voice could not make; guarded by liveLock
    @Volatile private var liveDone: (() -> Unit)? = null // called on the main thread when the live reply has been spoken to the end

    /**
     * Opens a live session (stops anything being said). False when there is no Gemini key. Finished pieces of the reply are
     * then fed with [liveFeed] and the end is signalled with [liveEnd]. If the Gemini voice fails part-way, the rest of the
     * reply is spoken with the phone's own voice once the reply is complete.
     * [onDone] (optional) is called on the main thread once everything has been spoken (also when the phone's voice finished the
     * rest). It is NOT called when the speech was stopped or replaced by something else.
     */
    fun liveStart(ctx: Context, onDone: (() -> Unit)? = null): Boolean {
        val app = ctx.applicationContext
        appCtx = app
        val cfg = NaturalVoice.config(app) ?: return false
        liveDone = onDone
        try { tts?.stop() } catch (e: Exception) { }
        try { track?.pause(); track?.flush() } catch (e: Exception) { }
        val my = ++naturalToken
        val q = java.util.concurrent.LinkedBlockingQueue<LiveItem>()
        synchronized(liveLock) { liveEnded = false; liveFailed = false; liveRest.setLength(0) }
        liveFedOnce = false
        liveQ = q
        liveCfg = cfg
        liveToken = my
        speaking = true
        pool.execute {
            var idle = 0
            var firstItem = true
            try {
                while (naturalToken == my) {
                    val item = q.poll(200, TimeUnit.MILLISECONDS)
                    if (item == null) { if (++idle > 600) break else continue } // nothing for 2 minutes: give up
                    idle = 0
                    val job = item.job ?: break
                    // The first words must not keep the user waiting: after 5 s the phone's own voice takes over.
                    val pcm = try { job.get(if (firstItem) 5L else 25L, TimeUnit.SECONDS) } catch (e: Exception) { null }
                    firstItem = false
                    if (naturalToken != my) break
                    if (pcm == null) { // cloud voice failed: this piece and everything after it is spoken by the phone's voice
                        var speakNow = false
                        synchronized(liveLock) {
                            liveFailed = true
                            liveRest.append(item.text).append(' ')
                            while (true) { val more = q.poll() ?: break; if (more.job != null) liveRest.append(more.text).append(' ') }
                            speakNow = liveEnded
                        }
                        if (speakNow) speakLiveRest(my)
                        break
                    }
                    playPcm(pcm, my)
                    // quiet at the punctuation, unless this was the last piece of the reply
                    val next = q.peek()
                    if (!(next != null && next.job == null)) pauseFor(gapAfter(item.text, false), my)
                }
            } catch (e: Exception) {
                // playback problem: treat like a failed voice so the reply is still read out
                var speakNow = false
                synchronized(liveLock) { liveFailed = true; speakNow = liveEnded }
                if (speakNow) speakLiveRest(my)
            } finally {
                q.forEach { it.job?.cancel(true) }
                main.post { if (naturalToken == my) speaking = false }
                // Spoken to the end by the Gemini voice (when it failed, speakLiveRest reports the end of the phone's voice instead)
                val failed = synchronized(liveLock) { liveFailed }
                if (!failed && naturalToken == my) fireLiveDone()
            }
        }
        return true
    }

    private fun fireLiveDone() {
        val d = liveDone
        liveDone = null
        if (d != null) main.post { try { d() } catch (e: Exception) { } }
    }

    private fun speakLiveRest(my: Long) {
        val text = synchronized(liveLock) { liveRest.toString().also { liveRest.setLength(0) } }.trim()
        val app = appCtx
        val d = liveDone
        liveDone = null
        if (app == null || text.isEmpty()) { if (d != null) main.post { try { d() } catch (e: Exception) { } }; return }
        main.post { if (naturalToken == my) { speaking = false; speakSystem(app, text, null, d) } }
    }

    /** One finished piece of the reply (a sentence or a few). Its voice is made at once, in order. */
    fun liveFeed(text: String) {
        val q = liveQ ?: return
        val cfg = liveCfg ?: return
        if (naturalToken != liveToken) return
        val t = split(text, addEnd = false).joinToString(" ").trim()
        if (t.isEmpty()) return
        synchronized(liveLock) {
            if (liveFailed) { liveRest.append(t).append(' '); return } // Gemini voice already failed: keep it for the phone voice
        }
        val first = q.isEmpty() && !liveFedOnce
        liveFedOnce = true
        q.add(LiveItem(t, pool.submit<ByteArray> { NaturalVoice.synth(cfg.key, t, cfg.voice, fast = first) }))
    }

    /** The reply is complete: the voice finishes what was fed and then stops. */
    fun liveEnd() {
        val q = liveQ ?: return
        var speakNow = false
        synchronized(liveLock) {
            liveEnded = true
            if (liveFailed) speakNow = true else q.add(LiveItem("", null))
        }
        if (speakNow) speakLiveRest(liveToken)
    }

    private fun playPcm(pcm: ByteArray, my: Long) {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(NaturalVoice.RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            val frames = pcm.size / 2
            t.play()
            val limit = System.currentTimeMillis() + frames * 1000L / NaturalVoice.RATE + 2000L
            while (naturalToken == my && t.playbackHeadPosition < frames && System.currentTimeMillis() < limit) Thread.sleep(25)
        } finally {
            try { t.setVolume(0f) } catch (e: Exception) { }
            try { t.stop() } catch (e: Exception) { }
            try { t.release() } catch (e: Exception) { }
            if (track === t) track = null
        }
    }

    fun stop() {
        main.post {
            naturalToken++
            try { track?.pause(); track?.flush() } catch (e: Exception) { }
            try { tts?.stop() } catch (e: Exception) { }
            sentences.clear()
            speaking = false
            onSentence = null
            onFinished = null
        }
    }

    /** Starts Google's speech engine when it is installed (it sounds far more natural than most phone-maker engines), otherwise the phone's default. */
    private fun init(app: Context, engine: String? = "com.google.android.tts") {
        val onInit = TextToSpeech.OnInitListener { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    tts?.setOnUtteranceProgressListener(listener)
                    queued?.invoke()
                    queued = null
                    queuedGiveUp = null
                } else if (engine != null) {
                    try { tts?.shutdown() } catch (e: Exception) { }
                    tts = null
                    init(app, null)
                } else {
                    initFailed = true
                    tts = null
                    queuedGiveUp?.invoke()
                    queued = null
                    queuedGiveUp = null
                }
            }
        }
        tts = try {
            if (engine != null) TextToSpeech(app, onInit, engine) else TextToSpeech(app, onInit)
        } catch (e: Exception) {
            if (engine != null) { init(app, null); return }
            null
        }
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            val e = sentences[utteranceId ?: return] ?: return
            main.post { onSentence?.invoke(e.first) }
        }

        override fun onDone(utteranceId: String?) = finish(utteranceId)

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) = finish(utteranceId)

        private fun finish(utteranceId: String?) {
            val e = sentences.remove(utteranceId ?: return) ?: return
            if (e.second) main.post {
                speaking = false
                val done = onFinished
                onFinished = null
                onSentence = null
                done?.invoke()
            }
        }
    }

    private fun say(text: String, onStart: ((String) -> Unit)?, onDone: (() -> Unit)?) {
        val engine = tts ?: run { onDone?.invoke(); return }
        val loc = pickLocale(engine, LangGuess.detect(text))
        engine.setLanguage(loc)
        applySystemVoice(engine, loc)
        val parts = splitP(text)
        if (parts.isEmpty()) { onDone?.invoke(); return }
        onSentence = onStart
        onFinished = onDone
        speaking = true
        val b = ++batch
        sentences.clear()
        parts.forEachIndexed { i, part ->
            val s = part.first
            val id = "neo_${b}_$i"
            sentences[id] = s to (i == parts.lastIndex)
            engine.speak(s, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
            // stop where the punctuation is, and a little longer where one message ends and the next begins
            val gap = gapAfter(s, part.second)
            if (i < parts.lastIndex && gap > 0L) engine.playSilentUtterance(gap, TextToSpeech.QUEUE_ADD, "neo_${b}_${i}_gap")
        }
    }

    /** Best installed voice of the chosen gender. Never picks a voice that is tagged as the other gender. */
    private fun applySystemVoice(engine: TextToSpeech, loc: Locale) {
        try {
            val male = appCtx?.let { NaturalVoice.gender(it) } == "male"
            // Google voices carry the speaker in their name (en-us-x-iol-local). Known male / female speakers are used
            // even when the name has no "male" / "female" tag.
            val maleIds = setOf("iol", "iom", "tpd", "rjs", "gbb", "gbd", "ahs", "cfc")
            val femaleIds = setOf("iob", "iof", "iog", "sfg", "tpc", "tpf", "gba", "gbc", "gbg", "fis", "afs", "cmn")
            fun speaker(v: Voice) = v.name.split('-', '_').firstOrNull { it in maleIds || it in femaleIds }
            fun isFemale(v: Voice) = v.name.contains("female", ignoreCase = true) || speaker(v) in femaleIds
            fun isMale(v: Voice) = (v.name.contains("male", ignoreCase = true) && !v.name.contains("female", ignoreCase = true)) || speaker(v) in maleIds
            val installed = engine.voices?.filter {
                it.locale.language == loc.language && it.features?.contains("notInstalled") != true
            }.orEmpty()
            val tagged = installed.filter { if (male) isMale(it) else isFemale(it) }
            // Never a voice known to be the other gender; untagged voices only when nothing tagged exists.
            val candidates = when {
                tagged.isNotEmpty() -> tagged
                male -> installed.filter { !isFemale(it) }
                else -> installed.filter { !isMale(it) }
            }
            val pick: Voice? = candidates.sortedWith(
                compareByDescending<Voice> { !it.isNetworkConnectionRequired }
                    .thenByDescending { loc.country.isNotEmpty() && it.locale.country == loc.country }
                    .thenByDescending { it.quality }
            ).firstOrNull()
            engine.setSpeechRate(0.95f)
            if (pick != null) engine.voice = pick
            engine.setPitch(if (tagged.isNotEmpty()) 1.0f else if (male) 0.85f else 1.0f)
        } catch (e: Exception) { }
    }

    private fun available(e: TextToSpeech, l: Locale) = try {
        e.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE
    } catch (ex: Exception) { false }

    private fun pickLocale(e: TextToSpeech, wanted: Locale?): Locale {
        val phone = Locale.getDefault()
        val fallback = if (available(e, phone)) phone else Locale.ENGLISH
        if (wanted == null) { voiceNote = ""; return fallback }
        if (available(e, wanted)) { voiceNote = ""; return wanted }
        val sw = Locale("sw")
        if (available(e, sw)) {
            voiceNote = "No Chichewa voice is installed, so I read it with a Swahili voice."
            return sw
        }
        voiceNote = "No Chichewa voice is installed, so I read it with the phone's normal voice."
        return fallback
    }

    /** Sentences for subtitles; very long ones are cut at a word so the engine's length limit is never hit. */
    private fun split(text: String, addEnd: Boolean = true): List<String> = splitP(text, addEnd).map { it.first }

    /**
     * The words the voice says, cut into sentences. Each message (line) gets a full stop if it has no end mark, spaces are put
     * after commas and other marks, and dashes become commas, so the voice pauses where the punctuation is. The flag says the
     * sentence is the last one of a message that is followed by another message.
     */
    private fun splitP(text: String, addEnd: Boolean = true): List<Pair<String, Boolean>> {
        val clean = text
            .replace(Regex("https?://\\S+"), " ")
            .replace(Regex("[*_#`]+"), "")
            .replace(Regex("[ \\t]+"), " ")
            .trim()
        val lines = clean.split(Regex("\\n+")).map { tidy(it) }.filter { it.isNotEmpty() }
        val out = mutableListOf<Pair<String, Boolean>>()
        lines.forEachIndexed { li, raw ->
            val line = if (addEnd) withEnd(raw) else raw
            val pieces = mutableListOf<String>()
            line.split(Regex("(?<=[.!?…])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }.forEach { sentence ->
                var rest = sentence
                while (rest.length > 150) {
                    val cut = rest.lastIndexOf(' ', 150).let { if (it < 50) 150 else it }
                    pieces += rest.substring(0, cut).trim()
                    rest = rest.substring(cut).trim()
                }
                if (rest.isNotEmpty()) pieces += rest
            }
            pieces.forEachIndexed { pi, piece -> out += piece to (pi == pieces.lastIndex && li < lines.lastIndex) }
        }
        return out
    }

    private fun tidy(line: String): String = line.trim()
        .replace(Regex("^[-•·–—]+\\s+"), "")                 // list bullets
        .replace(Regex("\\s+[-–—]+\\s+"), ", ")              // " - " and " — " are a pause
        .replace(Regex("([,;:!?])(?=\\p{L})"), "$1 ")        // "Hello,there" -> "Hello, there"
        .replace(Regex("\\s+([,;:!?])"), "$1")                // "word ," -> "word,"
        .replace(Regex("([!?]){2,}"), "$1")                   // "?!?!" -> one mark
        .replace(Regex(",{2,}"), ",")
        .replace(Regex("\\.{4,}"), "…")
        .trim()

    /** A message that has no end mark gets a full stop, so the voice finishes its sentence and stops. */
    private fun withEnd(s: String): String =
        if (s.isNotEmpty() && !Regex("[.!?…:;)\"”'’]$").containsMatchIn(s)) s.trimEnd(',', ';', ':', '-', '–', '—', ' ') + "." else s
}

/**
 * Things that happen later and on their own (a text message was delivered, ...). Shows up in the open chat panel, is
 * spoken with subtitles when the floating orb is running (or when "read replies aloud" is on), and falls back to a toast
 * so the news is never lost.
 */
object Announcer {
    private val handlers = CopyOnWriteArrayList<(String) -> Unit>()

    fun register(h: (String) -> Unit) { if (!handlers.contains(h)) handlers.add(h) }
    fun unregister(h: (String) -> Unit) { handlers.remove(h) }

    fun say(ctx: Context, text: String) {
        val app = ctx.applicationContext
        Handler(Looper.getMainLooper()).post {
            handlers.forEach { try { it(text) } catch (e: Exception) { } }
            val orb = OrbService.instance
            if (orb != null) {
                orb.say(text)
            } else if (app.getSharedPreferences("neo_assistant", Context.MODE_PRIVATE).getBoolean("speak", false)) {
                Speaker.speak(app, text, natural = false)
            } else if (handlers.isEmpty()) {
                Toast.makeText(app, text, Toast.LENGTH_LONG).show()
            }
        }
    }
}
